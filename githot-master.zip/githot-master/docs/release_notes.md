# Release notes

## v1.0.6
2015-12-16 14:19
彻底修复加载更多乱序问题
修复Oauth登陆后GitHub访问没限制啦

## v1.0.5
2015-12-14 12:57
修复hotusers排序bug
适配nexus4
修复部分手机systembar显示问题