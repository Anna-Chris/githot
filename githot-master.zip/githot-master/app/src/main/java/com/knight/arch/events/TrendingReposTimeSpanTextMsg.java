package com.knight.arch.events;


/**
 * @author andyiac
 * @date 15-10-19
 * @web http://blog.andyiac.com
 * @github https://github.com/andyiac
 */
public class TrendingReposTimeSpanTextMsg {
    String timeSpan;

    public String getTimeSpan() {
        return timeSpan;
    }

    public void setTimeSpan(String timeSpan) {
        this.timeSpan = timeSpan;
    }
}