package com.knight.arch.api;

/**
 * @author andyiac
 * @date 15/11/10
 * @web http://blog.andyiac.com
 * @github https://github.com/andyiac
 */
public class GitHubApiConstants {

    // todo id和 secret 是否放在其它地方
    public static String GITHUB_APP_CLIENT_ID = "d23f22372a297175a100";
    public static String GITHUB_APP_CLIENT_SECRET = "d0d616882a5ee2d9456a16a3c4e9f72e93ca1e4b";

}
